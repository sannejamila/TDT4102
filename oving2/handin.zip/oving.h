

void inputAndPrintInteger();

int inputInteger();

void inputIntegersAndPrintSum();

bool isOdd(int n);

void printHumanReadableTime(int sek);

void SumAvHeltall();

void sum_av_heltall();

double inputDouble();

double NOKtoEuro();

void multiplication_table();

double discriminant(double a, double b, double c);

void printRealRoots(double a, double b, double c);

void solveQuadrativEquation();

void pythagoras();

void calculateBalance(double now_saldo, double rente, int years);

void printBlance(vector<int> saldoer);




