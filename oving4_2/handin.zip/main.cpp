#include "std_lib_facilities.h"


int main()
{
	cout << "Hello, World!\n";
}

