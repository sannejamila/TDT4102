

double maxoftwo(double a, double b);

int fibonacci(int n);

int squareNumberSum(int n);

void trianglenumbersbelow(int n);

bool isPrime(int n);

void naivePrimeNumberSearch(int n);

int findGreatestDivisor(int n);
