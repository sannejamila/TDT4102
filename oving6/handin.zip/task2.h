#pragma once
#include <std_lib_facilities.h>

void print_number_of_chars(string file);