#pragma once
#include "std_lib_facilities.h"

void read_to_file();

void new_file(string filename);