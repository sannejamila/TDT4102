#pragma once

int randomWithLimits(int upper, int lower);
